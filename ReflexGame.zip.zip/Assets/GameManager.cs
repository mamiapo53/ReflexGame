using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameManager : MonoBehaviour
{
    public Button reflexButton;

    public TMP_Text scoreText;
    public TMP_Text timeText;
    public TMP_Text healthText;
    public TMP_Text gameOverText;

    int score = 0;
    int health = 5;

    float gameTime = 60f;
    float currentTime;

    float buttonTimer = 0f;

    float startStayTime = 1.5f;
    float endStayTime = 0.5f;

    float currentStayTime;

        void Start()
    {
        score = 0;

        currentTime = gameTime;

        gameOverText.gameObject.SetActive(false);

        reflexButton.onClick.AddListener(ButtonClicked);

        UpdateUI();

        MoveButton();
    }
    void Update()
    {
        currentTime -= Time.deltaTime;

        timeText.text =
            "Süre: " + Mathf.Ceil(currentTime);

        float progress =
            1 - (currentTime / gameTime);

        currentStayTime =
            Mathf.Lerp(startStayTime,
            endStayTime,
            progress);

        buttonTimer += Time.deltaTime;

        if (buttonTimer >= currentStayTime)
        {
            LoseHealth();

            MoveButton();

            buttonTimer = 0f;
        }

        healthText.text =
            "Can: " + health;

        scoreText.text =
            "Puan: " + score;

        if (currentTime <= 0 || health <= 0)
        {
            EndGame();
        }
    }

    void ButtonClicked()
    {
        score++;

        MoveButton();

        buttonTimer = 0f;
    }

    void MoveButton()
    {
        float x = Random.Range(-300f, 300f);
        float y = Random.Range(-150f, 150f);

        reflexButton.transform.localPosition =
            new Vector3(x, y, 0);
    }

    void LoseHealth()
    {
        health--;
    }

    void UpdateUI()
    {
        scoreText.text =
            "Puan: " + score;

        timeText.text =
            "Süre: " + Mathf.Ceil(currentTime);

        healthText.text =
            "Can: " + health;
    }

    void EndGame()
    {
        reflexButton.gameObject.SetActive(false);

        gameOverText.gameObject.SetActive(true);

        gameOverText.text =
            "OYUN BİTTİ\nSkor: " + score;

        enabled = false;
    }
}
